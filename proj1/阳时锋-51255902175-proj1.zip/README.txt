运行环境：基于python3.9，没有调用第三方库，理论上python3.x都可以正常运行
使用方法：python main.py [filepath/filename]，其中，文件置于main.py目录下时，无需带路径；置于其他目录下时，带绝对/相对路径
示       例：python main.py sample.txt
	 python main.py ../sample.txt