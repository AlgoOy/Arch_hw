"""
    - Get filename using command line arguments
    - Disassemble the binary code
    - Simulate assembly code
"""
import sys
import getfilename
import disassembler

if __name__ == "__main__":
    filename = getfilename.get_from_argv(sys.argv)
    disassembler.process(filename)
